﻿## **1. Internet**
Internet a diferencia de lo que se piensa no es una sola red, sino un conjunto de redes diferentes que usan ciertos protocolos comunes y proporcionan ciertos servicios comunes. Además, es un sistema que nadie planeó y nadie controla.
### **1.1 ARPANET**

La ARPANET surgió de un proyecto de ARPA (Agencia de Proyectos de Investigación Avanzada). Esta subred constaría de minicomputadoras llamadas IMPs (Procesadores de Mensajes de Interfaz), conectadas por líneas de transmisión de 56 kbps. Para alta confiabilidad, cada IMP estaría conectado al menos a otros dos IMPs. De manera que si se destruyen algunos IMPs, los mensajes se podrían volver a enrutar de manera automática a otras rutas alternativas.

Cada nodo de la red iba a constar de un IMP y un host, en el mismo cuarto, conectados por un cable corto. Un host tendría la capacidad de enviar mensajes de más de 8063 bits a su IMP, el cual los fragmentaría en paquetes de, a lo sumo, 1008 bits y los enviaría de manera independiente hacia el destino. Los IMPs no tenían discos, ya que las partes móviles se consideraban no confiables. Y estaban interconectadas por línea de 56kbps alquiladas a la compañías telefónicas.

El software estaba dividido en dos partes: subred y host. El software de la subred constaba del extremo IMP de la conexión host a IMP, del protocolo IMP a IMP y de un protocolo de IMP origen a IMP destino diseñado para mejorar la confiabilidad.

Sin embargo, había un problema, los host también necesitaban software, a raíz de esto en diciembre de 1969 de alguna manera surgió una red experimental con cuatro nodos: en UCLA, UCSB, SRI y la Universidad de Utah.

Más adelante experimentos demostraron que los protocolos existentes no eran adecuados para ejecutarse a través de varias redes. Por lo que se abrieron investigaciones que terminaron en la invención del modelo y los protocolos de TCP/IP. Este protocolo está diseñado de manera específica para manejar comunicación por interfaces, aspecto cuya importancia se acrecentó conforme cada vez más y más redes se adhirieron a ARPANET. También se desarrollaron los sockets y DNS.

  

### **1.2 NSFNET**

La NSF diseñó el sucesor de ARPANET que pudiera estar abierto a todos los grupos de investigación de las universidades. Ya que contaba con seis supercomputadoras se le dice a cada una un hermano menor, que consistía en una microcomputadora llamada fuzzball. Estas computadoras estaban conectadas a líneas alquiladas de 56 kbps y formaban una subred, utilizando la misma tecnología de hardware que ARPANET. Sin embargo, la tecnología de software era diferente: las fuzzball utilizan TCP/IP desde el inicio, creando así la primera WAN TCP/IP.

La NSFNET fue un éxito y se escaló dos veces hasta 1.5 Mbps. Hasta que en 1990, ANS (Redes y Servicios Avanzados), adquirió NSFNET y lo escaló hasta 45 Mbps para formar ANSNET.

  

### **1.3 Uso de Internet**

 
El TCP/IP hace posible el servicio universal y se puede comparar con la adopción de la medida estándar para el ancho de vía del ferrocarril en el siglo XIX o la adopción de protocolos de señalización comunes para las compañías telefónicas.

Pero, ¿Qué significa en realidad estar en Internet? El libro lo define como: una máquina que está en internet si ejecuta la pila de protocolos de TCP/IP, tiene una dirección IP y puede enviar paquetes IP a todas las demás máquinas en Internet.

Una nueva aplicación WWW (World Wide Web) cambió todo eso y trajo millones de usuarios nuevos no académicos a la red. Lo que hizo posible que un sitio estableciera páginas de información que contienen texto , imágenes, sonido e incluso vídeo , y vínculos integrados a otras páginas.

  

## **2. ATM**

La ATM es un tipo de red orientada a la conexión, tal vez el más importante, es ATM (Modo de transferencia Asincrónica). ATM tuvo mucho más éxito que OSI y actualmente tiene un uso profundo dentro del sistema telefónico, con frecuencia en el transporte de los paquetes IP.

La idea básica en que se fundamenta ATM es transmitir toda la información en paquetes pequeños, de tamaño fijo, llamados celdas. Las celdas tienen un tamaño de 53 bytes,, de los cuales cinco son del encabezado y 48 de carga útil.

Otro punto a favor de ATM es que el hardware se puede configurar para enviar una celda entrante a múltiples líneas de salida, una propiedad necesaria para el manejo de un programa de televisión que se va a difundir a varios receptores. Además, ATM, garantiza que las celdas nunca se entregarán en desorden.

El modelo de ATM consta de tres capas, la capa física tiene que ver con el medio físico, voltajes, temporización de bits, etc…

La capa ATM se encarga de las celdas y su transporte. El control de congestión también se ubica aquí.

Puesto que la mayoría de las aplicaciones no necesita trabajar de manera directa con las celdas (aunque algunas podrían hacerlo), se ha definido una capa superior a la capa ATM para que los usuarios envíen paquetes más grandes que una celda. La interfaz de ATM segmenta estos paquetes, transmite de forma individual las celdas y las reensambla en el otro extremo. Esta capa es la AAL (Capa de Adaptación ATM).

Cada una de las capas física y AAL se dividen en dos subredes, una en la parte inferior que hace el trabajo y en la subcapa de convergencia en la parte superior que proporciona la interfaz propia de la capa superior inmediata.
  

## **3. Ethernet**

Ethernet empezó basado en ALOHANET y básicamente consistía en un cable con múltiples máquinas en paralelo se llama cable de derivación múltiple (multidrop). El sistema se ejecutaba a 2.94 Mbps.

Ethernet tenía una mejora importante respecto de ALOHANET; antes de transmitir, una computadora tenía que escuchar el cable para ver si había alguien más transmitiendo. En caso de que ya lo hubiera, la computadora se mantenía en espera de que la transmisión actual terminará. Al hacerlo así se evitaba interferir con las transmisiones existentes, dando una mayor eficiencia.

A pesar de que la computadora escucha antes de transmitir, surge un problema: ¿qué sucede si dos o más computadoras esperan hasta que se complete la transmisión actual y luego empiezan a transmitir al mismo tiempo? La solución es que cada computadora escuche durante su propia transmisión y, si detecta interferencia, mande una señal para poner en alerta a todos los transmisores.

Después espera un tiempo aleatorio antes de intentarlo. Si sucede una colisión, el tiempo aleatorio de espera se duplica y así sucesivamente, para separar las transmisiones que están en competencia y dar a alguna la oportunidad de transmitir primero. La Ethernet de Xerox fue tan exitosa que DEC, Intel y Xerox diseñaron un estándar en 1978 para una Ethernet de 10 Mbps, llamado estándar DIX. Con dos cambios menores, en 1983 el estándar DIX se convirtió en el estándar IEEE 802.3.

Resumiendo, había una guerra entre Ethernet, Token Bus y Token Ring, pero Ethernet ganó, en gran medida porque fue la primera y los retadores no pudieron superarlo.
